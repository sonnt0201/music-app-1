//
//  Artist.swift
//  Music App
//
//  Created by Sơn Nguyễn on 10/07/2022.
//

import Foundation
