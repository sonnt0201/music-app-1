//
//  ProfileViewController.swift
//  Music App
//
//  Created by Sơn Nguyễn on 09/07/2022.
//

import UIKit

class ProfileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Cá nhân"
        
        APICallers.shared.getCurrentUserProfile { result in
            switch result {
            case .success(let model): break
            case .failure(let error): print(error.localizedDescription )
            }
        }
        
    }
    

    

}
